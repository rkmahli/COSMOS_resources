package com.liberty.affinity.policy.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import com.liberty.affinity.policy.assembler.GenderResourceAssembler;
import com.liberty.affinity.policy.assembler.PinCodeAssembler;
import com.liberty.affinity.policy.assembler.PolicyTermResourceAssembler;
import com.liberty.affinity.policy.assembler.RelationshipResourceAssembler;
import com.liberty.affinity.policy.assembler.TitleResourceAssembler;
import com.liberty.affinity.policy.domain.City;
import com.liberty.affinity.policy.domain.District;
import com.liberty.affinity.policy.domain.PinCode;
import com.liberty.affinity.policy.domain.State;
import com.liberty.affinity.policy.repository.CityRepository;
import com.liberty.affinity.policy.repository.DistrictRepository;
import com.liberty.affinity.policy.repository.GenderRepository;
import com.liberty.affinity.policy.repository.PinCodeRepository;
import com.liberty.affinity.policy.repository.PolicyTermRepository;
import com.liberty.affinity.policy.repository.RelationshipRepository;
import com.liberty.affinity.policy.repository.StateRepository;
import com.liberty.affinity.policy.repository.TitleRepository;
import com.liberty.affinity.policy.resource.GenderResource;
import com.liberty.affinity.policy.resource.PinCodeResource;
import com.liberty.affinity.policy.resource.PolicyTermResource;
import com.liberty.affinity.policy.resource.RegionDataResource;
import com.liberty.affinity.policy.resource.RelationshipResource;
import com.liberty.affinity.policy.resource.TitleResource;

@Service
public class ReferenceServiceImpl implements ReferenceService{
	
	@Autowired
    private GenderRepository genderRepository;
	@Autowired
    private RelationshipRepository relationRepository;
	@Autowired
    private GenderResourceAssembler genderAssembler;
	@Autowired
    private RelationshipResourceAssembler relationAssembler;
	
	@Autowired
    private StateRepository stateRepository;
	@Autowired
    private DistrictRepository districtRepository;
	@Autowired
    private CityRepository cityRepository;
	
	@Autowired
    private PinCodeRepository pinCodeRepository;
	
	@Autowired
    private PinCodeAssembler pinCodeAssembler;
	
	
	@Autowired
	private PolicyTermRepository termRepo;	
	@Autowired
	private PolicyTermResourceAssembler termAssembler;
	
	
	@Autowired
	private TitleRepository titleRepo;	
	@Autowired
	private TitleResourceAssembler titleAssembler;
	
	@Override
	public List<GenderResource> getGender() {
		
		return genderAssembler.toResources(genderRepository.findAll());
	}
	
	@Override
	public  List<RelationshipResource> getRelationTypes() {
		
		return relationAssembler.toResources(relationRepository.findAll());
	}
	
	@Override
	public List<PinCodeResource> getPinCodeData(String pinCode)
	{		
		return pinCodeAssembler.toResources(pinCodeRepository.getPincodeData(pinCode,PageRequest.of(0, 10)));

	}
	
	@Override
	public List<PolicyTermResource> getPolicyTerm()
	{
		return termAssembler.toResources(termRepo.findAll());
	}
	@Override
	public List<TitleResource> getTitles()
	{
		return titleAssembler.toResources(titleRepo.findAll());
	}   

	@Override
	public RegionDataResource getRegionData(String pinCode)
	{
		RegionDataResource regionData = null;
		
		List<PinCode> pincode = pinCodeRepository.findDistinctByPincode(pinCode,PageRequest.of(0, 1));
	
		if(pincode != null){
			State state = stateRepository.findDistinctByStateId(pincode.get(0).getStateId());
			District district = districtRepository.findDistinctByDistrictId(pincode.get(0).getDistrictId());
			City city = cityRepository.findDistinctByCityId(pincode.get(0).getCityiD());
			
			regionData = new RegionDataResource();
			regionData.setStateId(state.getStateId());
			regionData.setStateName(state.getStateName());
			regionData.setDistrictId(district.getDistrictId());
			regionData.setDistrictName(district.getDistrictName());
			regionData.setCityId(city.getCityId());
			regionData.setCityName(city.getCityName());			
			
		}		
				
		return regionData ; 
	}


}
