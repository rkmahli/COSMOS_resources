package com.liberty.affinity.policy.assembler;

import java.util.List;
import org.springframework.stereotype.Component;
import com.liberty.affinity.policy.domain.MasterPolicyDetail;
import com.liberty.affinity.policy.resource.MasterPolicyDetailResource;
import com.liberty.affinity.policy.utils.ModelMapperUtils;

@Component
public class MasterPolicyAssembler
{

	public MasterPolicyDetailResource toResource(MasterPolicyDetail masterPolicy)
	{
		return ModelMapperUtils.map(masterPolicy, MasterPolicyDetailResource.class);
	}
	
	public List<MasterPolicyDetailResource> toResources(List<MasterPolicyDetail> masterPolicyList)
	{
		return ModelMapperUtils.mapAll(masterPolicyList, MasterPolicyDetailResource.class);
	}
}
