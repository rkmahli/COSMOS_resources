/**
 * 
 */
package com.liberty.affinity.policy.assembler;

import java.util.List;

import org.springframework.stereotype.Component;

import com.liberty.affinity.policy.domain.Relationship;
import com.liberty.affinity.policy.resource.RelationshipResource;
import com.liberty.affinity.policy.utils.ModelMapperUtils;

/**
 * @author 421560
 *
 */
@Component
public class RelationshipResourceAssembler  {

	public RelationshipResource toResource(Relationship relationship)
	{
		return ModelMapperUtils.map(relationship, RelationshipResource.class);
	}
	
	public List<RelationshipResource> toResources(List<Relationship> relationshipList)
	{
		return ModelMapperUtils.mapAll(relationshipList, RelationshipResource.class);
	}
}
