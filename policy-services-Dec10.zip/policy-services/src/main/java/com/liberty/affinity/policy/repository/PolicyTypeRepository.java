/**
 * 
 */
package com.liberty.affinity.policy.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import com.liberty.affinity.policy.domain.PolicyType;

/**
 * @author 421560
 *
 */
public interface PolicyTypeRepository extends JpaRepository<PolicyType, Integer> {

	@Query(value="select a from PolicyType a where a.productId = :productId order by a.effectiveDate DESC")
	List<PolicyType> findEffectivePolicyTypes(@Param("productId") Integer productId);
	
}
