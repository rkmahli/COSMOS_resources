package com.liberty.affinity.policy.resource;

import org.springframework.hateoas.ResourceSupport;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=true)
public class ProposalCommunicationDetails extends ResourceSupport{
	
		private String address1;
		private String address2;
		private String address3;
		private String pincode;
		private String mobile;
		private String state;
		private String district;
		private String city;
		private String emailId;
		private String telephone;
			
		
}
