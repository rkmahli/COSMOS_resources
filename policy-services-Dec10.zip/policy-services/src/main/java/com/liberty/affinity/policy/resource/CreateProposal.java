package com.liberty.affinity.policy.resource;

import java.sql.Timestamp;
import java.util.List;

import org.springframework.hateoas.ResourceSupport;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.liberty.affinity.policy.domain.PolicyDetails;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=true)
public class CreateProposal extends ResourceSupport{
	
	private Integer affinityId;
	private Integer productId;
	private Integer planId;
	private String employeeId;
	
	private Integer policyTerm;
	private Integer policyId;
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="dd/MM/yyyy HH:mm:ss") //
	private Timestamp policyStartDate;
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="dd/MM/yyyy HH:mm:ss")
	private Timestamp policyEndDate;
	private String masterPolicyNo;
	private String sumInsured;
	private String paymentOption;
	private String gstNo;
	private String customerId;
	private Integer customerDetailId;
	private Integer branchId;
	
	private Integer PolicyStatusId;
	
	private PolicyDetails policyDetails;
		
	private List<ProposalBeneficiaryInfo> beneficiaryList;
	private List<ProposalQuestionInfo> questionList;
	private ProposalCommunicationDetails communicationDetails;
	
}
