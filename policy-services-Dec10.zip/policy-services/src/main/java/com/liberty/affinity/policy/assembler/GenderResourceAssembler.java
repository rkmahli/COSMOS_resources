package com.liberty.affinity.policy.assembler;

import java.util.List;
import org.springframework.stereotype.Component;
import com.liberty.affinity.policy.domain.Gender;
import com.liberty.affinity.policy.resource.GenderResource;
import com.liberty.affinity.policy.utils.ModelMapperUtils;

@Component
public class GenderResourceAssembler{
	
	public GenderResource toResource(Gender gender)
	{
		return ModelMapperUtils.map(gender, GenderResource.class);
	}
	
	public List<GenderResource> toResources(List<Gender> genderList)
	{
		return ModelMapperUtils.mapAll(genderList, GenderResource.class);
	}
}
