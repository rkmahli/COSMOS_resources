/**
 * 
 */
package com.liberty.affinity.policy.domain;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import lombok.Data;

/**
 * @author 421560
 *
 */

@Entity
@Data
@Table(name="customerdetail")
public class CustomerDetail {
	
	@Id
	private Integer customerDetailId;
	
	private String Name;
	
	private String customerId;
	
	private boolean isActive;
	
	@OneToMany(cascade = CascadeType.ALL,fetch = FetchType.EAGER,
	mappedBy = "policyCustomerDetails")
	private List<PolicyCommunicationDetails> policyCommunicationDetails;
	
}
