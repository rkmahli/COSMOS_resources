/**
 * 
 */
package com.liberty.affinity.policy.assembler;

import org.modelmapper.ModelMapper;
import org.springframework.hateoas.Link;
import static org.springframework.hateoas.mvc.ControllerLinkBuilder.*;

import java.lang.reflect.Method;
import org.springframework.hateoas.mvc.ResourceAssemblerSupport;
import org.springframework.stereotype.Component;

import com.liberty.affinity.policy.controller.PolicyController;
import com.liberty.affinity.policy.controller.ReferenceController;
import com.liberty.affinity.policy.domain.Product;
import com.liberty.affinity.policy.resource.ProductResource;
import com.liberty.affinity.policy.utils.ModelMapperUtils;

import lombok.extern.slf4j.Slf4j;

/**
 * @author 421560
 *
 */

@Component
@Slf4j
public class ProductResourceAssembler extends ResourceAssemblerSupport<Product, ProductResource> 
{

	public ProductResourceAssembler()
	{
		super(PolicyController.class, ProductResource.class);
	}
 
	@Override
	public ProductResource toResource(Product product) 
	{

		ProductResource productResource = ModelMapperUtils.map(product, ProductResource.class);

		try
		{
			Method selfMethod = PolicyController.class.getMethod("getProducts", Integer[].class);
			Link selfLink = linkTo(selfMethod, product.getProductid()).withSelfRel();

			Method questionMethod = PolicyController.class.getMethod("getQuestions", Integer.class);
			Link questionsLink = linkTo(questionMethod, product.getProductid()).withRel("questions");				
			
			Method masterPolicyMethod = PolicyController.class.getMethod("getMasterPolicyData", Integer.class);
			Link masterPolicyLink= linkTo(masterPolicyMethod, product.getProductid()).withRel("masterPolicy");
			
			Link policyTypeslink = linkTo(PolicyController.class).slash("product").slash(product.getProductid()).slash("policytypes").slash("?startDate=").withRel("policytypes");

			productResource.add(selfLink);
			productResource.add(questionsLink);
			productResource.add(masterPolicyLink);
			productResource.add(policyTypeslink);
			
			/*	
			Method genderMethod = ReferenceController.class.getMethod("getGenderTypes");
			Link genderLink = linkTo(genderMethod).withRel("gender");		
			
			Method relationMethod = ReferenceController.class.getMethod("getRelationTypes");
			Link relationTypesLink = linkTo(relationMethod).withRel("relationTypes");
			
			productResource.add(genderLink);
			productResource.add(relationTypesLink);*/
	
		} 
		catch (NoSuchMethodException e)
		{
			log.error("NoSuchMethod", e);
		} 
		catch (SecurityException e)
		{
			log.error("SecurityException", e);
		}

		return productResource;

	}

}
