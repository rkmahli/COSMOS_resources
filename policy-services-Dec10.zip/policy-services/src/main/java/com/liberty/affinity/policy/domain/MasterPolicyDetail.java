package com.liberty.affinity.policy.domain;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Data
@Table(name="masterpolicydetail")
public class MasterPolicyDetail {
	
	@Id
	private Integer MasterPolicyDetailId;	
	private Integer masterPolicyId;
	private Integer productId;
	

}
