/**
 * 
 */
package com.liberty.affinity.policy.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import com.liberty.affinity.policy.domain.Product;


/**
 * @author 421560
 *
 */
public interface ProductRepository extends JpaRepository<Product, Integer> {
	
	List<Product> findByproductidIn(Integer[] Productid);	
	
}
