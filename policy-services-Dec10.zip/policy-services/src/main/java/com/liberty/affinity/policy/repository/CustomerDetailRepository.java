package com.liberty.affinity.policy.repository;

import com.liberty.affinity.policy.domain.CustomerDetail;
import java.lang.String;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CustomerDetailRepository extends JpaRepository<CustomerDetail, Integer>{

	CustomerDetail findByCustomerId(String customerid);
}
