package com.liberty.affinity.policy.resource;

import lombok.Data;

@Data
public class QuoteGenerationResource {
	
	private Integer affinityCode;	
	private String applicationName;	
	private String notificationAction;
	
	private Integer quoteNumber;
	private String mobileNumber;
	private String emailId;
	private String paymentOption;
	private String viewQuoteURL;	
	private String paymentURL;
	
//	private String policyPaymentDetails;

}
