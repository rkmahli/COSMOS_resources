/**
 * 
 */
package com.liberty.affinity.policy.assembler;

import static org.springframework.hateoas.mvc.ControllerLinkBuilder.*;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.hateoas.Link;
import org.springframework.hateoas.mvc.ResourceAssemblerSupport;
import org.springframework.stereotype.Component;

import com.liberty.affinity.policy.controller.PolicyController;
import com.liberty.affinity.policy.domain.PolicyType;
import com.liberty.affinity.policy.resource.PolicyTypeResource;
import com.liberty.affinity.policy.utils.ModelMapperUtils;

/**
 * @author 421560
 *
 */
@Component
public class PolicyTypeResourceAssembler extends ResourceAssemblerSupport<PolicyType, PolicyTypeResource> 
{

	public PolicyTypeResourceAssembler() 
	{
		super(PolicyController.class, PolicyTypeResource.class);
	}
	
	
	@Override
	public PolicyTypeResource toResource(PolicyType policyType)
	{	
		PolicyTypeResource policyTypeResource = ModelMapperUtils.map(policyType, PolicyTypeResource.class);	
		
		try 
		{	
			Method plansMethod = PolicyController.class.getMethod("getPlanTypesForPolicyType", Integer[].class);
			Link plansLink = linkTo(plansMethod, policyType.getPolicytypeId()).withSelfRel();
			policyTypeResource.add(plansLink);
		}
		catch (NoSuchMethodException | SecurityException e) {
				e.printStackTrace();
		}
		
		return policyTypeResource;
	}

	/*@Override
	public PolicyTypeResource toResource(PolicyType policyType)
	{
		List<String> mappingFiles = new ArrayList<String>();
		mappingFiles.add("dozerJdk8Converters.xml"); 

		DozerBeanMapper dozerBeanMapper = new DozerBeanMapper();
		dozerBeanMapper.setMappingFiles(mappingFiles);
		
		PolicyTypeResource policyTypeResource = dozerBeanMapper.map(policyType, PolicyTypeResource.class);

		
			//Link selflink = linkTo(PolicyController.class.getMethod("getPolicyTypesForStartDate", Integer[].class,LocalDateTime.class)).slash("?startDate=").withSelfRel();
			
		Link link = linkTo(PolicyController.class).slash("product").slash(policyType.getProductId()).slash("policytypes").slash("?startDate=").withSelfRel();
		
		Link link2 = linkTo(PolicyController.class).slash("product").slash(policyType.getProductId()).slash("policytypes").slash(policyType.getPolicytypeId()).slash("getplans").withRel("planTypes");

			Link link2 =  linkTo(methodOn(PolicyController.class).methodWithMultiValueRequestParams(policyTypes.getProductId()))
							.withSelfRel();
			Link selfLink = linkTo(selfMethod, product.getProductid()).withSelfRel();

			policyTypeResource.add(link);
			policyTypeResource.add(link2);
	
		
		return policyTypeResource;

	}*/

}
