package com.liberty.affinity.policy.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.liberty.affinity.policy.domain.MasterPolicyDetail;
import java.lang.Integer;
import java.util.List;

@Repository
public interface MasterPolicyRepository extends JpaRepository<MasterPolicyDetail, Integer>{

	List<MasterPolicyDetail> findByProductId(Integer productid);
	
}
