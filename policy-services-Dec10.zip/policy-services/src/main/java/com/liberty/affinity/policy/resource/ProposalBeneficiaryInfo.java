package com.liberty.affinity.policy.resource;

import java.time.LocalDate;

import org.springframework.hateoas.ResourceSupport;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=true)
public class ProposalBeneficiaryInfo extends ResourceSupport {
	
	
	private String name;
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="dd/MM/yyyy")
	private LocalDate dob;
	private Integer genderid;
	private Integer proposerRelation;
	private String nomineeName;
	private Integer nomineeRelation;
	private Integer nomineeType; 	
	private String others;

}
