/**
 * 
 */
package com.liberty.affinity.policy.resource;

import java.util.Date;
import org.springframework.hateoas.ResourceSupport;
import lombok.Getter;
import lombok.Setter;

/**
 * @author 421560
 *
 */
@Getter
@Setter
public class ProductResource extends ResourceSupport{
	
	private Integer productid;
	
	private String Productname;	
	
	private Integer Lobid;
	
	private String shortProductname;
	
	private Date  startdate;
	
	private Date  Enddate;
	
	private Integer Riskstartdaterange ;
	
	private boolean Backdatedinception;	
	
	private Integer Backdatedinceptionrange;

}
