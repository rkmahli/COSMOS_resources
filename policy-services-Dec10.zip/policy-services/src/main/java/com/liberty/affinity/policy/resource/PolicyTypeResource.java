/**
 * 
 */
package com.liberty.affinity.policy.resource;

import java.time.LocalDateTime;
import org.springframework.hateoas.ResourceSupport;

import lombok.Data;
import lombok.EqualsAndHashCode;



/**
 * @author 421560
 *
 */

@Data
@EqualsAndHashCode(callSuper=true)
public class PolicyTypeResource  extends ResourceSupport{
	
	private Integer policytypeId;
	
	private String policyTypeName;
	
	private LocalDateTime effectiveDate;
	 
	private Integer productId;		
	

}
