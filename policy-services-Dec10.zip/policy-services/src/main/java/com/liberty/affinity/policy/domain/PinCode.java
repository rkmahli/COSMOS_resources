package com.liberty.affinity.policy.domain;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Entity
@Data
@EqualsAndHashCode(callSuper=false)
@Table(name="pincode")
public class PinCode {

	@Id
	private Integer pincodeId;
	private String pincode;
	
	private Integer stateId;
	private Integer districtId;
	private Integer cityiD;
	
	private boolean isActive;


	private String pincode_locality;

	
}
