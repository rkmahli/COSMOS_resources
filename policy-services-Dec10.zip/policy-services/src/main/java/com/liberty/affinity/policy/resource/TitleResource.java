package com.liberty.affinity.policy.resource;

public class TitleResource {
	private Integer titleId;
	private String titleName;
}
