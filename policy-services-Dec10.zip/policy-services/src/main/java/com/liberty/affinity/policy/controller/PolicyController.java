/**
 * 
 */
package com.liberty.affinity.policy.controller;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.liberty.affinity.common.exception.AffinityException;
import com.liberty.affinity.common.exception.NoDataFoundException;
import com.liberty.affinity.policy.resource.CreateProposal;
import com.liberty.affinity.policy.resource.MasterPolicyDetailResource;
import com.liberty.affinity.policy.resource.PlanTypeResource;
import com.liberty.affinity.policy.resource.PolicyCreationRequestWrapper;
import com.liberty.affinity.policy.resource.PolicyTypeResource;
import com.liberty.affinity.policy.resource.ProductResource;
import com.liberty.affinity.policy.resource.QuestionResource;
import com.liberty.affinity.policy.service.PolicyService;



/**
 * @author 421560
 *
 */
@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/policy")
public class PolicyController
{
	
	@Autowired
	private PolicyService service ;		
	
	@GetMapping(path="/product/{productID}")
    public ResponseEntity<List<ProductResource>> getProducts(@PathVariable ("productID")  Integer[] productID)
    {
						
		List<ProductResource> productsList = service.getProducts(productID);
		
		if(productsList.isEmpty() || productsList.size()==0)
		{			
			throw new NoDataFoundException("No Products found across the given ids : " + Arrays.toString(productID));   
		}
		
		return new ResponseEntity<>(productsList,HttpStatus.OK);	
    }
	
	@GetMapping("/product/{productID}/questions") 
    public ResponseEntity<List<QuestionResource>> getQuestions(@PathVariable Integer productID)
	{	
		List<QuestionResource> questionsList = service.getQuestions(productID);
		
		if(questionsList.isEmpty() || questionsList.size()==0)
		{			
			throw new NoDataFoundException("No questions found for the product ids : "+ productID);   
		}
		
		return new ResponseEntity<>(service.getQuestions(productID),HttpStatus.OK);	
    }
	
	
	@GetMapping("/product/{productID}/policytypes") 
    public ResponseEntity<List<PolicyTypeResource>> getPolicyTypesForStartDate(@PathVariable Integer productID,
    		@RequestParam(name = "startDate")@DateTimeFormat(pattern="dd/MM/yyyy HH:mm:ss")LocalDateTime startDate) throws AffinityException,Exception
	{						
		return new ResponseEntity<>(service.getPolicyTypesForStartDate(productID,startDate),HttpStatus.OK);	
    }
	
	@GetMapping("/plans/{policytypeid}")  // Remove the productId from the URL 
    public ResponseEntity<List<PlanTypeResource>> getPlanTypesForPolicyType(@PathVariable Integer[] policytypeid) throws AffinityException,Exception
	{						
		return new ResponseEntity<>(service.getPlanTypesForPolicyType(policytypeid),HttpStatus.OK);	
    } 
	
	
	@GetMapping("/masterPolicy/{productID}") 
    public ResponseEntity<List<MasterPolicyDetailResource>> getMasterPolicyData(@PathVariable ("productID")  Integer productID) throws AffinityException,Exception
	{						
		return new ResponseEntity<>(service.getMasterPolicyData(productID),HttpStatus.OK);	
    }
	
	@PostMapping("/quote")  
	public ResponseEntity<CreateProposal> saveQuote(@RequestBody  PolicyCreationRequestWrapper policyCreationRequest) 
	{
							
		 return new ResponseEntity<>(service.saveQuote(policyCreationRequest),HttpStatus.CREATED);	
		
	}
			
}
