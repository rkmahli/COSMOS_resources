package com.liberty.affinity.policy.proxy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

import com.liberty.affinity.common.exception.KafkaException;
import com.liberty.affinity.kafka.client.producer.ProducerClient;

import lombok.Data;


@Component
public class PolicyProxy 
{	
	@Autowired
	ProducerClient producer;

	
	//private String jsonTypeString;
	
	public void sendMessage(String topic,String payLoad) throws KafkaException
	{		
		
	/*	AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		context.scan("com.liberty.affinity.kafka.client");*/
		//context.refresh();
	//	ProducerClient obj = (ProducerClient) context.getBean(ProducerClient.class); 
		
		try {
			producer.publishMessage(topic,payLoad);
		} catch (KafkaException e) {
			
			throw new KafkaException("Jeez ! Kafka error!");
		}
	}
	
	/*public void receiveMessage(String messageResponse)
	{ 
		System.out.println("hello response got from Kafka affinity  "+ messageResponse);
		//service.setPlanDataJSONString(messageResponse);
		//resource.setPlanDetailsJSONString(messageResponse);
	//	jsonTypeString = messageResponse;
		System.out.println("After the method end ");
	
	}	*/
	

/*	public void listenConsumer(String topic) throws KafkaException
	{
		 
		consumer.processMessage();
		
	}*/
	
	/*@KafkaListener(topics = "${kafka_consumer_topic}", groupId = "${kafka_consumer_group_id_info}")
	  public void receiveMessage(String messageResponse)
		{
			System.out.println("policy service : : kafka listener response >>> "+ messageResponse);
			//jsonTypeString = messageResponse;
		}*/
}	
