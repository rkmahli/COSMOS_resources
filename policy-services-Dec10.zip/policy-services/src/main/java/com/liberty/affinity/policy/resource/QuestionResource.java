package com.liberty.affinity.policy.resource;

import java.util.List;

import org.springframework.hateoas.ResourceSupport;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
public class QuestionResource{

	
	private Integer questionId;
	
	private Integer productId;
	
	private String question;
	
	private List<ChoicesResource> choices;
}
