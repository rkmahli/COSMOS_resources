package com.liberty.affinity.policy.resource;

import lombok.Data;

@Data
public class DistrictResource {
	
	private Integer districtId;
	private String districtName;
	
	private boolean isActive;

}
