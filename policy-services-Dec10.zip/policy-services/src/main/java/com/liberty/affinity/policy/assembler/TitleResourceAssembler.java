package com.liberty.affinity.policy.assembler;

import java.util.List;
import org.springframework.stereotype.Component;
import com.liberty.affinity.policy.domain.Title;
import com.liberty.affinity.policy.resource.TitleResource;
import com.liberty.affinity.policy.utils.ModelMapperUtils;

@Component
public class TitleResourceAssembler {
	
	public TitleResource toResource(Title title)
	{
		return ModelMapperUtils.map(title, TitleResource.class);
	}
	
	public List<TitleResource> toResources(List<Title> titleList)
	{
		return ModelMapperUtils.mapAll(titleList, TitleResource.class);
	}

}
