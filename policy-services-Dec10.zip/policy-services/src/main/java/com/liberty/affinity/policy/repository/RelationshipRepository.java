package com.liberty.affinity.policy.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.liberty.affinity.policy.domain.Relationship;

public interface RelationshipRepository extends JpaRepository<Relationship, Integer>{

}
