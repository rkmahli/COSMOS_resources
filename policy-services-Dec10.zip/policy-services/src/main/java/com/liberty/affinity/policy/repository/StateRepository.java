package com.liberty.affinity.policy.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.liberty.affinity.policy.domain.State;

public interface StateRepository extends JpaRepository<State, Integer> {
	
/*	@Query(value="select DISTINCT a from State a inner join a.districts b on a.stateId =b.state.stateId inner join b.cities c"
			+ " on b.districtId = c.district.districtId inner join c.pinCodes d on c.cityId = d.city.cityId AND d.pincode = :pincode AND a.stateId= 31")
	State getRegionData(@Param("pincode") String pincode);*/
	
	/*@Query(value="select DISTINCT a from State a join a.districts b on a.stateId =b.stateId join b.cities c"
			+ " on b.districtId = c.districtId join PinCode d on c.cityId = d.cityId AND d.pincode = :pincode")
	State getRegionData(@Param("pincode") String pincode);*/
	
	State findDistinctByStateId(Integer StateId);

}
