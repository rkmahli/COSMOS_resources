/**
 * 
 */
package com.liberty.affinity.policy.domain;

import java.io.Serializable;
import java.sql.Date;
import java.time.LocalDate;
import javax.persistence.Embeddable;
import lombok.Data;

/**
 * @author 421560
 *
 */
@Embeddable
@Data
public class PolicyBeneficiaryComposite implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Integer Policyid;
//	@Mapping("name")
	private String name;
//	@Mapping("dob")
	private LocalDate dob;

}
