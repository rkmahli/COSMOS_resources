/**
 * 
 */
package com.liberty.affinity.policy.domain;

import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import lombok.Data;

/**
 * @author 421560
 *
 */

@Entity
@Data
@Table(name="policydetails")
public class PolicyDetails  {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
//	@Mapping("policyId")
	private Integer policyId;
	
//	@Mapping("affinityId")
	@Column(name="Affinityid") 
	private Integer Affinityid;
//	@Mapping("productId")
	private Integer ProductID; 
//	@Mapping("planId")
	private Integer planId;
	
//	@Mapping("policyStartDate")
	private Timestamp policyStartDate;
	
//	@Mapping("policyEndDate")
	private Timestamp policyEndDate;	
	
//	@Mapping("PolicyStatusId")
	private Integer PolicyStatusId;
//	@Mapping("branchId")
	private Integer BranchId;	

	private Integer LastUpdatedBy;
	
	private Integer customerDetailId;
	
//	@Mapping("employeeCode")
	private String employeeId;	
	private Integer policyTermId;
//	@Mapping("policyTerm")
	private Integer masterPolicyNo;
	private Integer Covernoteno; 
	

}
