/**
 * 
 */
package com.liberty.affinity.policy.assembler;

import org.modelmapper.ModelMapper;
import org.springframework.hateoas.mvc.ResourceAssemblerSupport;
import org.springframework.stereotype.Component;

import com.liberty.affinity.policy.controller.PolicyController;
import com.liberty.affinity.policy.domain.PolicyBeneficiaryDetails;
import com.liberty.affinity.policy.resource.ProposalBeneficiaryInfo;
import com.liberty.affinity.policy.utils.ModelMapperUtils;

/**
 * @author 421560
 *
 */
@Component
public class PolicyBeneficiaryAssembler extends ResourceAssemblerSupport<PolicyBeneficiaryDetails, ProposalBeneficiaryInfo> 
{

	public PolicyBeneficiaryAssembler() 
	{
		super(PolicyController.class, ProposalBeneficiaryInfo.class);
	}

	@Override
	public ProposalBeneficiaryInfo toResource(PolicyBeneficiaryDetails entity) 
	{
		return  ModelMapperUtils.map(entity, ProposalBeneficiaryInfo.class);
	}
}
