package com.liberty.affinity.policy.assembler;

import java.util.List;

import org.springframework.stereotype.Component;

import com.liberty.affinity.policy.domain.Question;
import com.liberty.affinity.policy.resource.QuestionResource;
import com.liberty.affinity.policy.utils.ModelMapperUtils;

@Component
public class QuestionResourceAssembler
{
	public QuestionResource toResource(Question question)
	{
		return ModelMapperUtils.map(question, QuestionResource.class);
	}
	
	public List<QuestionResource> toResources(List<Question> questionsList)
	{
		return ModelMapperUtils.mapAll(questionsList, QuestionResource.class);
		
	}

}
