package com.liberty.affinity.policy.assembler;


import static org.springframework.hateoas.mvc.ControllerLinkBuilder.linkTo;

import java.lang.reflect.Method;

import org.springframework.hateoas.Link;
import org.springframework.hateoas.mvc.ResourceAssemblerSupport;
import org.springframework.stereotype.Component;
import com.liberty.affinity.policy.controller.PolicyController;
import com.liberty.affinity.policy.controller.ReferenceController;
import com.liberty.affinity.policy.domain.PinCode;
import com.liberty.affinity.policy.resource.PinCodeResource;
import com.liberty.affinity.policy.utils.ModelMapperUtils;

@Component
public class PinCodeAssembler extends ResourceAssemblerSupport<PinCode, PinCodeResource>
{

	public PinCodeAssembler() 
	{
		super(PolicyController.class, PinCodeResource.class);
	}
	
	@Override
	public PinCodeResource toResource(PinCode pinCode)
	{
		
		PinCodeResource resource = ModelMapperUtils.map(pinCode, PinCodeResource.class);
		resource.setPincodeInfo(pinCode.getPincode().concat("-").concat(pinCode.getPincode_locality()));
		
		try {
		Method regionDataMethod = ReferenceController.class.getMethod("getRegionInfo", String.class);
		Link regionInfoLink = linkTo(regionDataMethod, pinCode.getPincode()).withRel("RegionInfo");
		resource.add(regionInfoLink);
		} catch (NoSuchMethodException | SecurityException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		
		return resource;
	}
	

}
