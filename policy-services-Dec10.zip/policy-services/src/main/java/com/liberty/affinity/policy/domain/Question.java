/**
 * 
 */
package com.liberty.affinity.policy.domain;

import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import lombok.Data;

/**
 * @author 421560
 *
 */

@Entity
@Table(name="productquestions")
@Data
public class Question {

	@Id
//	@Mapping("Questionid")
	private Integer questionId;
	
//	@Mapping("Productid")
	private Integer productId;
	
//	@Mapping("Question")
	private String question;
	
	@OneToMany(mappedBy= "question",cascade= CascadeType.ALL
			,fetch=FetchType.EAGER)
	private List<Choice> choices;
	
}
