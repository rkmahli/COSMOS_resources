package com.liberty.affinity.policy.resource;

import lombok.Data;

@Data
public class RegionDataResource {
	
	private Integer stateId;
	private String stateName; 
	
	private Integer districtId;
	private String districtName;
	
	private Integer cityId;
	private String cityName ;
}
