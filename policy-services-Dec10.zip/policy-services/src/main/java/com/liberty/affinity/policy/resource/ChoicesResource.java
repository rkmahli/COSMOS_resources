package com.liberty.affinity.policy.resource;

import lombok.Data;

@Data
public class ChoicesResource {
	
	private String choiceValue;


}
