/**
 * 
 */
package com.liberty.affinity.policy.resource;


import lombok.Data;

/**
 * @author 421560
 *
 */
@Data
public class PlanTypeResource{	

	private Integer planid;
	
	private String planTypeName;
	
	private Integer policytypeid; 

}
