/**
 * 
 */
package com.liberty.affinity.policy.domain;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author 421560
 *
 */
@Entity
@Data
@EqualsAndHashCode(callSuper=true)
@Table(name="plantype")
public class PlanType extends Auditable{	

	@Id
	private Integer planid;
	
	private String planTypeName;
	
	private Integer policytypeid; 
	
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "policytypeId", nullable = false)
    private PolicyType policyType;


	
}
