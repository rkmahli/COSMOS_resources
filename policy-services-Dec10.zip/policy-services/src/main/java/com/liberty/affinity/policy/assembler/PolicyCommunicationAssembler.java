/**
 * 
 */
package com.liberty.affinity.policy.assembler;

import org.modelmapper.ModelMapper;
import org.springframework.hateoas.mvc.ResourceAssemblerSupport;
import org.springframework.stereotype.Component;

import com.liberty.affinity.policy.controller.PolicyController;
import com.liberty.affinity.policy.domain.PolicyCommunicationDetails;
import com.liberty.affinity.policy.resource.ProposalCommunicationDetails;
import com.liberty.affinity.policy.utils.ModelMapperUtils;

/**
 * @author 421560
 *
 */
@Component
public class PolicyCommunicationAssembler extends ResourceAssemblerSupport<PolicyCommunicationDetails, ProposalCommunicationDetails>
{

	public PolicyCommunicationAssembler() 
	{
		super(PolicyController.class, ProposalCommunicationDetails.class);
	}

	@Override
	public ProposalCommunicationDetails toResource(PolicyCommunicationDetails entity) 
	{
		return ModelMapperUtils.map(entity, ProposalCommunicationDetails.class);
	}

}
