package com.liberty.affinity.policy.resource;

import lombok.Data;

@Data
public class MasterPolicyDetailResource {
	
	private Integer MasterPolicyDetailId;	
	private Integer masterPolicyId;
	private Integer productId;

}
