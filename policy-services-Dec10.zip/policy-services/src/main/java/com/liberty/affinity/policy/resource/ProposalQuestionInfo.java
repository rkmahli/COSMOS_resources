package com.liberty.affinity.policy.resource;

import lombok.Data;

@Data
public class ProposalQuestionInfo {
	
	private int questionId;
	private boolean questionAns;
	
}
