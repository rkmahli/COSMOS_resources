/**
 * 
 */
package com.liberty.affinity.policy.domain;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

/**
 * @author 421560
 *
 */
@Entity
@Data
@Table(name="gender")
public class Gender {
	
	@Id
	private Integer genderId;
	private String genderName;
	
 
}
