/**
 * 
 */
package com.liberty.affinity.policy.service;

import static java.util.Comparator.comparing;
import static java.util.stream.Collectors.collectingAndThen;
import static java.util.stream.Collectors.toCollection;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.TreeSet;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.jasypt.util.text.BasicTextEncryptor;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.util.UriBuilder;
import org.springframework.web.util.UriTemplate;

import com.google.gson.Gson;
import com.liberty.affinity.common.exception.AffinityException;
import com.liberty.affinity.common.exception.KafkaException;
import com.liberty.affinity.policy.assembler.MasterPolicyAssembler;
import com.liberty.affinity.policy.assembler.PlanTypeResourceAssembler;
import com.liberty.affinity.policy.assembler.PolicyBeneficiaryAssembler;
import com.liberty.affinity.policy.assembler.PolicyTermResourceAssembler;
import com.liberty.affinity.policy.assembler.PolicyTypeResourceAssembler;
import com.liberty.affinity.policy.assembler.ProductResourceAssembler;
import com.liberty.affinity.policy.assembler.ProposalResourceAssembler;
import com.liberty.affinity.policy.assembler.QuestionResourceAssembler;
import com.liberty.affinity.policy.domain.CustomerDetail;
import com.liberty.affinity.policy.domain.PolicyBeneficiaryComposite;
import com.liberty.affinity.policy.domain.PolicyBeneficiaryDetails;
import com.liberty.affinity.policy.domain.PolicyCommunicationDetails;
import com.liberty.affinity.policy.domain.PolicyDetails;
import com.liberty.affinity.policy.proxy.PolicyProxy;
import com.liberty.affinity.policy.repository.CustomerDetailRepository;
import com.liberty.affinity.policy.repository.MasterPolicyRepository;
import com.liberty.affinity.policy.repository.PlanTypeRepository;
import com.liberty.affinity.policy.repository.PolicyBeneficiaryRepository;
import com.liberty.affinity.policy.repository.PolicyCommunicationRepository;
import com.liberty.affinity.policy.repository.PolicyRepository;
import com.liberty.affinity.policy.repository.PolicyTypeRepository;
import com.liberty.affinity.policy.repository.ProductRepository;
import com.liberty.affinity.policy.repository.QuestionRepository;
import com.liberty.affinity.policy.resource.CreateProposal;
import com.liberty.affinity.policy.resource.MasterPolicyDetailResource;
import com.liberty.affinity.policy.resource.PlanTypeResource;
import com.liberty.affinity.policy.resource.PolicyCreationRequestWrapper;
import com.liberty.affinity.policy.resource.PolicyTermResource;
import com.liberty.affinity.policy.resource.PolicyTypeResource;
import com.liberty.affinity.policy.resource.ProductResource;
import com.liberty.affinity.policy.resource.ProposalBeneficiaryInfo;
import com.liberty.affinity.policy.resource.QuestionResource;
import com.liberty.affinity.policy.resource.QuoteGenerationResource;

import lombok.extern.slf4j.Slf4j;

/**
 * @author 421560
 *
 */
@Slf4j
@Service
public class PolicyServiceImpl implements PolicyService {
	
	@Autowired
    private ProductRepository productRepository;
	@Autowired
    private QuestionRepository questionRepository;

	@Autowired
    private PolicyRepository policyRepository;
	@Autowired
    private PolicyCommunicationRepository commRepository;
	@Autowired
    private PolicyBeneficiaryRepository beneRepository;
	@Autowired
    private ProductResourceAssembler productAssembler;
	@Autowired
    private QuestionResourceAssembler questionAssembler;

	@Autowired
    private PolicyTypeResourceAssembler policyTypeAssembler;
	@Autowired
    private ProposalResourceAssembler proposalAssembler;
	@Autowired
    private PolicyBeneficiaryAssembler beneAssembler;
	

	@Autowired
	private MasterPolicyRepository masterPolicyRepo;
	@Autowired
	private MasterPolicyAssembler masterPolicyAssembler;
	
	@Autowired
    private PlanTypeRepository planTypeRepository;
	@Autowired
	private PlanTypeResourceAssembler planTypeAssembler;
	

	@Autowired
    private PolicyTypeRepository policyTypeRepository;
	
	@Autowired
    private CustomerDetailRepository customerRepository;
	
	@Autowired
    private PolicyProxy kafkaProxy;
	
	@Value("${view.quote.url}")
	private String viewQuoteURL;
	
	@Value("${view.payment.url.template}")
	private String paymentURLTemplate;
	
	@Value("${view.payment.url}")
	private String paymentURL;
	

	@Override
	public List<ProductResource> getProducts(Integer[] ProductId) 
	{
		return productAssembler.toResources(productRepository.findByproductidIn(ProductId));
	} 
	
	@Override
	public List<MasterPolicyDetailResource> getMasterPolicyData(Integer productId) {
	
		return masterPolicyAssembler.toResources(masterPolicyRepo.findByProductId(productId));
	}
 

	@Override
	public List<PolicyTypeResource> getPolicyTypesForStartDate(Integer productId,LocalDateTime policyStartDate) throws AffinityException {		
		
				
		List<PolicyTypeResource> policyTypeResourceList =  policyTypeAssembler.toResources(policyTypeRepository.findEffectivePolicyTypes(productId));	
		
		ListIterator<PolicyTypeResource> iterator = policyTypeResourceList.listIterator();
		
		while(iterator.hasNext())
		{
			PolicyTypeResource resource = iterator.next();
			if(resource.getEffectiveDate().isAfter(policyStartDate))
			{
				iterator.remove();
			}
			
		}	
				
		List<PolicyTypeResource> effectivePolicyTypes = policyTypeResourceList.stream()
                .collect(collectingAndThen(toCollection(() -> new TreeSet<> (comparing(PolicyTypeResource::getPolicyTypeName))),
                                           ArrayList<PolicyTypeResource>::new));
		
		effectivePolicyTypes.sort((o1, o2) -> o1.getPolicytypeId().compareTo(o2.getPolicytypeId()));
		 
		 return effectivePolicyTypes;
	}   
	
	@Override
	public List<PlanTypeResource> getPlanTypesForPolicyType(Integer[] policyTypeId)
	{
		return planTypeAssembler.toResources(planTypeRepository.findByPolicytypeidIn(policyTypeId));
	}
		
	@Override
	public List<QuestionResource> getQuestions(Integer productId) 
	{
		return questionAssembler.toResources(questionRepository.findByProductId(productId));
	}
	
	@Override
	@Transactional()
	public CreateProposal saveQuote(PolicyCreationRequestWrapper policyCreationRequest) {	
		
	
		PolicyDetails policyDetailsEntity = new ModelMapper().map(policyCreationRequest.getPolicyDetails(), PolicyDetails.class);		
		policyDetailsEntity.setLastUpdatedBy(1);
		policyDetailsEntity.setPolicyStatusId(1);	// SAVE 	
		CustomerDetail customer = customerRepository.findByCustomerId(policyCreationRequest.getPolicyDetails().getCustomerId());
		policyDetailsEntity.setCustomerDetailId(customer.getCustomerDetailId());
		
		CreateProposal policyResource = proposalAssembler.toResource(policyRepository.save(policyDetailsEntity));	
						
		//CommunicationDEtails save		
		PolicyCommunicationDetails communicationEntity =  new ModelMapper().map(policyCreationRequest.getPolicyDetails().getCommunicationDetails(), PolicyCommunicationDetails.class);		
		if(null!=policyResource ){
			communicationEntity.setPolicyId(policyResource.getPolicyId());
		//	communicationEntity.setC(policyResource.getCustomerId());		// Please check here for customer detail save
		}
		//policyResource.setCommunicationDetails(communicationAssembler.toResource(commRepository.save(communicationEntity)));
		commRepository.save(communicationEntity);
		
		//Beneficiary Save 
		
	   /* List<PolicyBeneficiaryDetails> entityList = policyCreationRequest.getPolicyDetails().getBeneficiaryList().stream()
	                                .map(resourceObj ->  new DozerBeanMapper().map(resourceObj, PolicyBeneficiaryDetails.class))
	                .collect(Collectors.toList());
		*/
		ListIterator<ProposalBeneficiaryInfo> iterator =  policyCreationRequest.getPolicyDetails().getBeneficiaryList().listIterator();
		List<PolicyBeneficiaryDetails> entityList =  new ArrayList<>();
		while(iterator.hasNext()){
			ProposalBeneficiaryInfo resObj = iterator.next();			
			ModelMapper modelMapper = new ModelMapper();
			PolicyBeneficiaryDetails entityObj = modelMapper.map(resObj, PolicyBeneficiaryDetails.class);
			PolicyBeneficiaryComposite compositeId = new PolicyBeneficiaryComposite();
			compositeId.setName(resObj.getName());
			compositeId.setDob(resObj.getDob());
			compositeId.setPolicyid(policyResource.getPolicyId());
			entityObj.setPolicyBeneficiaryID(compositeId);					
			entityList.add(entityObj);
			
			}
		     
	     policyResource.setBeneficiaryList(beneAssembler.toResources(entityList.stream().map(beneEntity -> beneRepository.save(beneEntity))
	    		   .collect(Collectors.toList())));
	     
	     QuoteGenerationResource kafkaRes= new QuoteGenerationResource();
	     kafkaRes.setAffinityCode(1);
	     kafkaRes.setApplicationName("affinity");
	     kafkaRes.setNotificationAction("QuoteGeneration");
	     kafkaRes.setPaymentOption("1");//payU
	     kafkaRes.setMobileNumber(communicationEntity.getMobile());
	     kafkaRes.setEmailId(communicationEntity.getEmailID());
	     kafkaRes.setQuoteNumber(policyResource.getPolicyId());
	     kafkaRes.setViewQuoteURL(viewQuoteURL + policyResource.getPolicyId());	 	 	  
	     
	     BasicTextEncryptor textEncryptor = new BasicTextEncryptor();
	     String input = "sg9fok|MA10021|1500|healthProduct|muthu|muthu.raman@cognizant.com|||||||||||GISxVdDL";
	     textEncryptor.setPasswordCharArray("affinityEncryption".toCharArray());	     
	     String policyPaymentDetails = textEncryptor.encrypt(input);		     
	     policyPaymentDetails = policyPaymentDetails.replace("+", "%2B");
	     
	     UriTemplate uriTemplate = new UriTemplate(paymentURLTemplate);
	     Map<String, String> parameters =  uriTemplate.match(paymentURL);
	     parameters.put("applicationId","1");
	     parameters.put("gateWayId","1");	     
	     parameters.put("policyPaymentDetails", policyPaymentDetails);	  
	     
	     kafkaRes.setPaymentURL(uriTemplate.expand(parameters).toString()); //TO DO
	         
	     Gson gson = new Gson();
	     String kafkaResJSON = gson.toJson(kafkaRes);

	     try {
			kafkaProxy.sendMessage("QuoteGeneration",kafkaResJSON );
		} catch (KafkaException e) {
			// TODO Auto-generated catch block
			log.error(e.getMessage());
		}
	     
	  		
		return policyResource;
		
	}


	

		

}
