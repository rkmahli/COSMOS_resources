package com.liberty.affinity.policy.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.liberty.affinity.common.exception.AffinityException;
import com.liberty.affinity.common.exception.NoDataFoundException;
import com.liberty.affinity.policy.resource.GenderResource;
import com.liberty.affinity.policy.resource.PinCodeResource;
import com.liberty.affinity.policy.resource.PolicyTermResource;
import com.liberty.affinity.policy.resource.RegionDataResource;
import com.liberty.affinity.policy.resource.RelationshipResource;
import com.liberty.affinity.policy.resource.TitleResource;
import com.liberty.affinity.policy.service.ReferenceService;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/reference")
public class ReferenceController {
	
	@Autowired
	private ReferenceService service ;	
	
	@GetMapping("/gender")  
    public ResponseEntity<List<GenderResource>> getGenderTypes()
	{	
		List<GenderResource> gender = service.getGender();
		
		if(gender.isEmpty())
		{			
			throw new NoDataFoundException("No gender Values found");   
		}
		
		return new ResponseEntity<>(gender,HttpStatus.OK);	
    }
	
	
	@GetMapping("/term") 
    public ResponseEntity<List<PolicyTermResource>> getPolicyTerm()
	{	
		List<PolicyTermResource> termList = service.getPolicyTerm();
		
		if(termList.isEmpty() || termList.size()==0)
		{			
			throw new NoDataFoundException("No term details found");   
		}
		
		return new ResponseEntity<>(termList,HttpStatus.OK);	
    }	
	
	@GetMapping("/title") 
    public ResponseEntity<List<TitleResource>> getTitles()
	{	
		List<TitleResource> titlesList = service.getTitles();
		
		if(titlesList.isEmpty() || titlesList.size()==0)
		{			
			throw new NoDataFoundException("No title details found");   
		}
		
		return new ResponseEntity<>(titlesList,HttpStatus.OK);	
    }
	
	
	@GetMapping("/relationtypes") 
    public ResponseEntity<List<RelationshipResource>> getRelationTypes()
	{	
		List<RelationshipResource> relationTypes = service.getRelationTypes();
		
		if(relationTypes.isEmpty())
		{			
			throw new NoDataFoundException("No relationTypes found");   
		}
		
		return new ResponseEntity<>(relationTypes,HttpStatus.OK);	
    }
	
	
	@GetMapping("/pincodes/{pincode}") 
    public ResponseEntity<List<PinCodeResource>> getPinCodeData(@PathVariable String pincode) throws AffinityException,Exception
	{						
		return new ResponseEntity<>(service.getPinCodeData(pincode),HttpStatus.OK);	// handle negative scenarios
    }
	
	@GetMapping("/regions/{pincode}") 
    public ResponseEntity<RegionDataResource> getRegionInfo(@PathVariable String pincode) throws AffinityException,Exception
	{						
		return new ResponseEntity<>(service.getRegionData(pincode),HttpStatus.OK);	
    }

}
