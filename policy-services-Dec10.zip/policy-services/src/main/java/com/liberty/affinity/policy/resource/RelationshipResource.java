package com.liberty.affinity.policy.resource;


import lombok.Data;

@Data
public class RelationshipResource {
	
	private Integer relationId;
	private String relationType;
}
