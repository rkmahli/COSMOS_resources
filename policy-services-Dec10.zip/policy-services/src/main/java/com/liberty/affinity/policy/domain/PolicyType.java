/**
 * 
 */
package com.liberty.affinity.policy.domain;

import java.time.LocalDateTime;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author 421560
 *
 */

@Entity
@Data
@EqualsAndHashCode(callSuper=true)
@Table(name="policytype")
public class PolicyType extends Auditable{
	

	@Id
	private Integer policytypeId;
	
	private String policyTypeName;
	
	private LocalDateTime effectiveDate;
	
	private Integer productId;		
	
	@OneToMany(cascade = CascadeType.ALL,fetch = FetchType.EAGER,
	mappedBy = "policyType")
	private List<PlanType> plans;
}
