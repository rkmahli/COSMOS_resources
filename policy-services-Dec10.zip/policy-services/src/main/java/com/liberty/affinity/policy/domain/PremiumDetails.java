package com.liberty.affinity.policy.domain;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Data
@Table(name="premiumdetails")
public class PremiumDetails {
	
	@Id
	private Integer premiumId;
	private Integer policyId;
	private BigDecimal netPremium;
	private BigDecimal cgst;
	private BigDecimal sgst;
	private BigDecimal igst;
	private BigDecimal grossPremium;
	private LocalDateTime startDate;
	private LocalDateTime endDate;
	

}
