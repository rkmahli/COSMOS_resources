package com.liberty.affinity.policy.resource;

import lombok.Data;

@Data
public class GenderResource {
	
	private Integer genderId;
	private String genderName;

}
