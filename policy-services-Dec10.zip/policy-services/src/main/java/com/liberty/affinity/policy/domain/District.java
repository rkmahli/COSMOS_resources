package com.liberty.affinity.policy.domain;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Entity
@Data
@EqualsAndHashCode(callSuper=false)
@Table(name="district")
public class District {
	
	@Id
	private Integer districtId;
	private String districtName;
	
	private Integer stateId;
	
	private boolean isActive;

}
