package com.liberty.affinity.policy.assembler;

import java.util.List;

import org.springframework.stereotype.Component;

import com.liberty.affinity.policy.domain.PolicyTerm;
import com.liberty.affinity.policy.resource.PolicyTermResource;
import com.liberty.affinity.policy.utils.ModelMapperUtils;

@Component
public class PolicyTermResourceAssembler {
	
	public PolicyTermResource toResource(PolicyTerm policyTerm)
	{
		return ModelMapperUtils.map(policyTerm, PolicyTermResource.class);
	}
	
	public List<PolicyTermResource> toResources(List<PolicyTerm> termList)
	{
		return ModelMapperUtils.mapAll(termList, PolicyTermResource.class);
	}

}
