package com.liberty.affinity.policy.domain;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Table(name="choices")
@Data
public class Choice {
	
	@Id
	private Integer choiceid;
	private String choiceValue;
	
	@ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "questionId")
	private Question question;

}
