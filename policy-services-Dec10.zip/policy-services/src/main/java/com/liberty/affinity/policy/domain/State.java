/**
 * 
 */
package com.liberty.affinity.policy.domain;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author 421560
 *
 */
@Entity
@Data
@EqualsAndHashCode(callSuper=false)
@Table(name="state")
public class State {
	
	@Id
	private Integer stateId;
	private String stateName;	
	
	private boolean isActive;


}
