/**
 * 
 */
package com.liberty.affinity.policy.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.liberty.affinity.policy.domain.PlanType;
import java.lang.Integer;

/**
 * @author 421560
 *
 */
@Repository
public interface PlanTypeRepository extends JpaRepository<PlanType, Integer>{
	
	List<PlanType> findByPolicytypeidIn(Integer[] policyTypeId);	 
	
}
