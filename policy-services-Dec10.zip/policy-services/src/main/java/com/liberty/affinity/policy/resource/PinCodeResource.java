package com.liberty.affinity.policy.resource;

import org.springframework.hateoas.ResourceSupport;

import lombok.Data;

@Data
public class PinCodeResource extends ResourceSupport{
	
	private Integer pincodeId;
	private String pincode;
	
	private Integer stateID;
	private String pincode_locality;
	
	private String pincodeInfo;
	
	private boolean isActive;

}
