package com.liberty.affinity.policy.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.liberty.affinity.policy.domain.City;

public interface CityRepository extends JpaRepository<City, Integer> {
	
	City findDistinctByCityId(Integer cityId);

}
