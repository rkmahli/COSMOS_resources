package com.liberty.affinity.policy.domain;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Data
@Table(name="titles")
public class Title {
	
	@Id
	private Integer titleId;
	private String titleName;

}
