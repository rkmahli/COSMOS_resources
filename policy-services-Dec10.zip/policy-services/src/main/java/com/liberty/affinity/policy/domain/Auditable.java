/**
 * 
 */
package com.liberty.affinity.policy.domain;

import java.sql.Timestamp;

import javax.persistence.EntityListeners;
import javax.persistence.MappedSuperclass;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import lombok.Data;

/**
 * @author 421560
 *
 */
@MappedSuperclass
@EntityListeners(AuditingEntityListener.class)
@Data
public abstract class Auditable {

    @CreatedDate
    protected Timestamp creationTimeStamp;

    @LastModifiedDate
    protected Timestamp LastUpdatedTimeStamp;

}
