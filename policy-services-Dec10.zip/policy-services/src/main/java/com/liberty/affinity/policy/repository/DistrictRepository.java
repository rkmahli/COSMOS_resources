package com.liberty.affinity.policy.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.liberty.affinity.policy.domain.District;

public interface DistrictRepository extends JpaRepository<District, Integer> {
	
	District findDistinctByDistrictId(Integer districtId);

}