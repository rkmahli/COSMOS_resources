package com.liberty.affinity.policy.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.liberty.affinity.policy.domain.PolicyTerm;

public interface PolicyTermRepository  extends JpaRepository<PolicyTerm, Integer>{

	
}
