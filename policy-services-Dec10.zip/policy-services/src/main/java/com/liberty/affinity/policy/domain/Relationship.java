package com.liberty.affinity.policy.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Data
@Table(name="relationship")
public class Relationship {

	@Id
	private Integer relationId;
	
	@Column(name="Type")
	private String relationType;
}
