/**
 * 
 */
package com.liberty.affinity.policy.resource;



import lombok.Data;

/**
 * @author 421560
 *
 */

@Data
public class PolicyCreationRequestWrapper {

	CreateProposal policyDetails;	   


}
