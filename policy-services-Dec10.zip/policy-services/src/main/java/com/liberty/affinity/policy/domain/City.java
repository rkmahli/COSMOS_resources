package com.liberty.affinity.policy.domain;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Entity
@Data
@EqualsAndHashCode(callSuper=false)
@Table(name="city")
public class City {
	@Id
	private Integer cityId;
	private String cityName;
	private boolean isActive;
	
	private Integer districtId;
	

}
