package com.liberty.affinity.policy.service;

import java.util.List;

import com.liberty.affinity.policy.resource.GenderResource;
import com.liberty.affinity.policy.resource.PinCodeResource;
import com.liberty.affinity.policy.resource.PolicyTermResource;
import com.liberty.affinity.policy.resource.RegionDataResource;
import com.liberty.affinity.policy.resource.RelationshipResource;
import com.liberty.affinity.policy.resource.TitleResource;

public interface ReferenceService {
	
	   List<GenderResource> getGender() ;
	   
	   List<PolicyTermResource> getPolicyTerm() ;    
	   
	   List<TitleResource> getTitles() ; 
	   
	   List<RelationshipResource> getRelationTypes() ;
	   
	   List<PinCodeResource> getPinCodeData(String pinCode);
	   
	   RegionDataResource getRegionData(String pinCode);

}
