/**
 * 
 */
package com.liberty.affinity.policy.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;

/**
 * @author 421560
 *
 */
@Configuration
@EnableJpaAuditing
public class AuditConfg {		

	    @Bean
	    public AuditingEntityListener createAuditingListener() {
	        return new AuditingEntityListener();
	    }

	  
}
