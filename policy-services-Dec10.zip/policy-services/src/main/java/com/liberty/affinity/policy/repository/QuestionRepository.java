package com.liberty.affinity.policy.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import com.liberty.affinity.policy.domain.Question;

	public interface QuestionRepository extends JpaRepository<Question, Integer> {
		
		List<Question> findByProductId(Integer Productid);				
		
	}


