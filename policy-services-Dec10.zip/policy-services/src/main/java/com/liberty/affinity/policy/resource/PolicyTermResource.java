package com.liberty.affinity.policy.resource;

import lombok.Data;

@Data
public class PolicyTermResource {
	
	private Integer policyTermId;	
	private String policyTerm;

}
