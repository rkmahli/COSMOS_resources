package com.liberty.affinity.policy.assembler;

import org.modelmapper.ModelMapper;
import org.springframework.hateoas.mvc.ResourceAssemblerSupport;
import org.springframework.stereotype.Component;

import com.liberty.affinity.policy.controller.PolicyController;
import com.liberty.affinity.policy.domain.PolicyDetails;
import com.liberty.affinity.policy.resource.CreateProposal;


@Component
public class ProposalResourceAssembler extends ResourceAssemblerSupport<PolicyDetails,CreateProposal>
{
		
	public ProposalResourceAssembler()
	{
	    super(PolicyController.class,CreateProposal.class);
	} 
	
	@Override
	public CreateProposal toResource(PolicyDetails entity) 
	{		
		return new ModelMapper().map(entity, CreateProposal.class);
	}

}
