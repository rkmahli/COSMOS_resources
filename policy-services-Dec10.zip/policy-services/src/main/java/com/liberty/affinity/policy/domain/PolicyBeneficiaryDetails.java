/**
 * 
 */
package com.liberty.affinity.policy.domain;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import lombok.Data;

/**
 * @author 421560
 *
 */
@Entity
@Table(name="beneficiary_info")
@Data
public class PolicyBeneficiaryDetails extends Auditable{
	
	@EmbeddedId
	private PolicyBeneficiaryComposite policyBeneficiaryID;
	
	private Integer genderid;
//	@Mapping("proposerRelation")
	private Integer Relation_proposer;
//	@Mapping("nomineeName")
	private String nomineename;
//	@Mapping("nomineeRelation")
	private Integer Relation_nominee;
//	@Mapping("nomineeType")
	private Integer nominee_type;
	
	private String others;

}
