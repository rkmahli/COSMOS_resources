package com.liberty.affinity.policy.resource;

import java.util.List;

import org.springframework.hateoas.ResourceSupport;

import lombok.Data;

@Data
public class StateResource extends ResourceSupport{

	private Integer stateId;
	private String stateName;	
	
	private boolean isActive;
	
	private List<DistrictResource> districts;
	
}
