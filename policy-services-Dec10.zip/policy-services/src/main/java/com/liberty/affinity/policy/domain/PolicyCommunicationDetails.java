/**
 * 
 */
package com.liberty.affinity.policy.domain;


import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author 421560
 *
 */
@Entity
@Table(name="customeraddress")
@Data
@EqualsAndHashCode(callSuper=true)
public class PolicyCommunicationDetails extends Auditable {

	@Id
	private Integer policyId;
	
//	@Mapping("address1")
	private String Address1;
//	@Mapping("address2")
	private String Address2;
//	@Mapping("address3")
	private String Address3;
//	@Mapping("state")
	private String State;
//	@Mapping("district")
	private String District;
//	@Mapping("city")
	private String City;
//	@Mapping("pincode")
	private String Pincode;
//	@Mapping("emailId")
	private String EmailID;
//	@Mapping("mobile")
	private String Mobile;
//	@Mapping("telephone")
	private String Telephone;	
	
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "customerDetailId", nullable = false)
	private CustomerDetail policyCustomerDetails;

	
}
