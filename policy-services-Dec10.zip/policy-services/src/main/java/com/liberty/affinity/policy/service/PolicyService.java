package com.liberty.affinity.policy.service;

import java.time.LocalDateTime;
import java.util.List;

import com.liberty.affinity.common.exception.AffinityException;
import com.liberty.affinity.policy.resource.CreateProposal;
import com.liberty.affinity.policy.resource.MasterPolicyDetailResource;
import com.liberty.affinity.policy.resource.PlanTypeResource;
import com.liberty.affinity.policy.resource.PolicyCreationRequestWrapper;
import com.liberty.affinity.policy.resource.PolicyTypeResource;
import com.liberty.affinity.policy.resource.ProductResource;
import com.liberty.affinity.policy.resource.QuestionResource;


public interface PolicyService {
	
   List<ProductResource>  getProducts(Integer[] id) ;
   
   List<PlanTypeResource> getPlanTypesForPolicyType(Integer[] policyTypeId) ;
   
   List<QuestionResource> getQuestions(Integer id) ;  
      
   List<PolicyTypeResource> getPolicyTypesForStartDate(Integer productId,LocalDateTime time) throws AffinityException;
   
   List<MasterPolicyDetailResource> getMasterPolicyData(Integer productId);
    
   CreateProposal saveQuote(PolicyCreationRequestWrapper policyCreationRequest);     
   
  
}
