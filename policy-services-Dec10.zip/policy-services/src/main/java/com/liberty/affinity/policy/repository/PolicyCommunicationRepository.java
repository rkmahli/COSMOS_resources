/**
 * 
 */
package com.liberty.affinity.policy.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.liberty.affinity.policy.domain.PolicyCommunicationDetails;

/**
 * @author 421560
 *
 */
public interface PolicyCommunicationRepository extends JpaRepository<PolicyCommunicationDetails, Integer> {

}
