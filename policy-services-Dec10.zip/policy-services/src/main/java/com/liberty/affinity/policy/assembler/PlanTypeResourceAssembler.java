/**
 * 
 */
package com.liberty.affinity.policy.assembler;

import java.util.List;

import org.springframework.stereotype.Component;

import com.liberty.affinity.policy.domain.PlanType;
import com.liberty.affinity.policy.resource.PlanTypeResource;
import com.liberty.affinity.policy.utils.ModelMapperUtils;
/**
 * @author 421560
 *
 */
@Component
public class PlanTypeResourceAssembler

{
	public PlanTypeResource toResource(PlanType planType)
	{
		return ModelMapperUtils.map(planType, PlanTypeResource.class);
	}
	
	public List<PlanTypeResource> toResources(List<PlanType> planTypeList)
	{
		return ModelMapperUtils.mapAll(planTypeList, PlanTypeResource.class);
		
	}
	
}
