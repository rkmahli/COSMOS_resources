package com.liberty.affinity.policy.repository;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.liberty.affinity.policy.domain.PinCode;
import java.lang.String;

@Repository
public interface PinCodeRepository extends JpaRepository<PinCode, Integer> {

	@Query(value="select a from PinCode a where a.pincode like :pinCode% order by a.pincode,a.pincodeId ASC")
	List<PinCode> getPincodeData(@Param("pinCode") String pinCode,Pageable page);
	
	List<PinCode>  findDistinctByPincode(String pincode,Pageable page);
	
}
