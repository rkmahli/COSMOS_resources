
package demo.cosmos.core.policy.dao.impl;

import java.util.List;
import java.util.Map;
import demo.cosmos.core.policy.dao.PolicyDao;
import demo.cosmos.core.policy.dao.entity.Planbreakup;
import demo.cosmos.core.policy.dao.entity.Policydetails;
import demo.cosmos.core.policy.dao.entity.Product;
import demo.cosmos.core.policy.dao.entity.ProductquestionChoice;
import demo.cosmos.core.policy.dao.repository.PlanbreakupRepository;
import demo.cosmos.core.policy.dao.repository.PolicydetailsRepository;
import demo.cosmos.core.policy.dao.repository.ProductRepository;
import demo.cosmos.core.policy.dao.repository.ProductquestionChoiceRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class PolicyDaoImpl
    implements PolicyDao
{

    @Autowired
    private ProductRepository productRepository;
    @Autowired
    private PlanbreakupRepository planbreakupRepository;
    @Autowired
    private ProductquestionChoiceRepository productquestionChoiceRepository;
    @Autowired
    private PolicydetailsRepository policydetailsRepository;

    public Product getProductsUsingGET(String productID, Map<String, ?> headers) {
        return productRepository.findOne(productID);
    }

    public List<Planbreakup> getPlansUsingGET(Map<String, ?> headers) {
        return planbreakupRepository.findAll();
    }

    public List<ProductquestionChoice> getQuestionsUsingGET(Map<String, ?> headers) {
        return productquestionChoiceRepository.findAll();
    }

    public Policydetails saveQuoteUsingPOST(Policydetails policydetails, Map<String, ?> headers) {
        policydetails = policydetailsRepository.save(policydetails);
        // TODO: your code goes here..
        return policydetails;
    }

}
