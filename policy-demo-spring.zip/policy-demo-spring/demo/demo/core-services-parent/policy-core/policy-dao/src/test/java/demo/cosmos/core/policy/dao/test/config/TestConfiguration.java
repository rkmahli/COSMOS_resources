
package demo.cosmos.core.policy.dao.test.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan(basePackages = "demo.cosmos.core.policy.dao")
public class TestConfiguration {


}
