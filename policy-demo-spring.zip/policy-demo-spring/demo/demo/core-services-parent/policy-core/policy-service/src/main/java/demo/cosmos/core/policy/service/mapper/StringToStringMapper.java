
package demo.cosmos.core.policy.service.mapper;

import com.cognizant.cosmos.core.utils.mapper.BaseMapper;
import org.springframework.stereotype.Component;

@Component
public class StringToStringMapper
    extends BaseMapper<String, String>
{


}
