
package demo.cosmos.core.policy.service.mapper;

import com.cognizant.cosmos.core.utils.mapper.BaseMapper;
import demo.cosmos.core.policy.model.ModelAndView;
import org.springframework.stereotype.Component;

@Component
public class ModelAndViewToStringMapper
    extends BaseMapper<ModelAndView, String>
{


}
